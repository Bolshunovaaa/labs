<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }
    echo "<p>Привіт, {$_SESSION['user']}!</p>";
    echo '<a href="logout.php">Вихід</a>';
?>
