<?php
    session_start();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $login = $_POST['login'] ?? '';
        $password = $_POST['password'] ?? '';
        if ($login === 'admin' && $password === '1234') {
            $_SESSION['user'] = $login;
            $_SESSION['last_activity'] = time();
            header('Location: welcome.php');
            exit;
        } else {
            echo "<p>Невірні дані</p>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        Логін: <input name="login">
        Пароль: <input name="password" type="password">
        <button>Увійти</button>
    </form>
</body>
</html>
