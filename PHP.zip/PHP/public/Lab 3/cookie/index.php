<?php
    $name = $_COOKIE['username'] ?? '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['delete'])) {
            setcookie('username', '', time() - 3600);
            $name = '';
        } else {
            $name = $_POST['username'] ?? '';
            if ($name) {
                setcookie('username', $name, time() + 7 * 24 * 60 * 60);
            }
        }
        header("Location: index.php");
        exit;
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <?php if ($name): ?>
            <p>Привіт, <?= htmlspecialchars($name) ?>!</p>
            <button name="delete">Видалити cookie</button>
        <?php else: ?>
            Введіть ім'я: <input name="username">
            <button type="submit">Зберегти</button>
        <?php endif; ?>
    </form>
</body>
</html>
