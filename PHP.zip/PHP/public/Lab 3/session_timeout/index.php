<?php
    session_start();
    $timeout = 300;

    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout) {
        session_unset();
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/');
        echo "<p>Сесію завершено через неактивність.</p>";
    } else {
        $_SESSION['last_activity'] = time();
        echo "<p>Сесія активна. Час оновлено.</p>";
    }
?>

<a href="index.php">Оновити сторінку</a>
