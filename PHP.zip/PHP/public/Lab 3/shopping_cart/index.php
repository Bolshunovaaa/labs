<?php
    session_start();
    $previous = json_decode($_COOKIE['previous_cart'] ?? '[]', true);

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_POST['clear'])) {
        $merged = array_merge($previous, $_SESSION['cart']);
        setcookie('previous_cart', json_encode($merged), time() + 7 * 24 * 60 * 60);

        session_unset();
        session_destroy();
        header('Location: index.php');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['clear'])) {
        $item = $_POST['item'] ?? '';
        if ($item) {
            $_SESSION['cart'][] = $item;
        }
        header('Location: index.php');
        exit;
    }
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Кошик</title>
</head>
<body>
    <form method="POST">
        Товар: <input name="item">
        <button type="submit">Додати</button>
        <button type="submit" name="clear">Очистити корзину</button>
    </form>

    <p>Поточна корзина: <?= implode(', ', $_SESSION['cart']) ?></p>
    <p>Попередні покупки: <?= implode(', ', $previous) ?></p>
</body>
</html>
