<?php
    require_once 'BankAccount.php';
    require_once 'SavingsAccount.php';

    function displayBalance($label, $amount) {
        echo "<tr><td><strong>{$label}</strong></td><td>{$amount}</td></tr>";
    }

    function performStandardAccountDemo() {
        $acc = new BankAccount("USD", 100);
        echo "<h3>Звичайний рахунок (USD)</h3>";
        
        echo "<table border='1' cellpadding='5'>";
        displayBalance("Початковий баланс", $acc->getBalance());
        $acc->deposit(50);
        displayBalance("Після поповнення", $acc->getBalance());
        $acc->withdraw(30);
        displayBalance("Після зняття", $acc->getBalance());
        echo "</table>";
    }

    function performSavingsAccountDemo() {
        $saver = new SavingsAccount("EUR", 400);
        echo "<h3>Накопичувальний рахунок (EUR)</h3>";

        echo "<table border='1' cellpadding='5'>";
        displayBalance("До нарахування відсотків", $saver->getBalance());
        $saver->applyPercentage();
        displayBalance("Після нарахування відсотків", $saver->getBalance());
        echo "</table>";
    }

    function triggerErrors() {
        $acc = new BankAccount("USD", 100);
        echo "<h3>Перевірка обробки помилок</h3>";

        echo "<ul>";
        try {
            $acc->withdraw(-25);
        } catch (Exception $e) {
            echo "<li><span style='color:red;'>Помилка зняття: {$e->getMessage()}</span></li>";
        }

        try {
            $acc->deposit(-100);
        } catch (Exception $e) {
            echo "<li><span style='color:red;'>Помилка поповнення: {$e->getMessage()}</span></li>";
        }

        try {
            $acc->withdraw(9999);
        } catch (Exception $e) {
            echo "<li><span style='color:red;'>Недостатньо коштів: {$e->getMessage()}</span></li>";
        }

        try {
            $invalid = new BankAccount("USD", -500);
        } catch (Exception $e) {
            echo "<li><span style='color:red;'>Помилка створення рахунку: {$e->getMessage()}</span></li>";
        }
        echo "</ul>";
    }

    try {
        echo "<h2>Тестування банківської системи</h2>";
        performStandardAccountDemo();
        performSavingsAccountDemo();
        triggerErrors();
    } catch (Exception $e) {
        echo "<p style='color:red;'>Неочікувана помилка: {$e->getMessage()}</p>";
    }
?>
