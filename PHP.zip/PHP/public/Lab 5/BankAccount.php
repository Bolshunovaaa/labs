<?php
    require_once 'AccountInterface.php';

    class BankAccount implements AccountInterface {
        protected $balance;
        protected $currency;
        const MIN_BALANCE = 0;

        public function __construct($currency, $initialBalance = 0) {
            if ($initialBalance < self::MIN_BALANCE) {
                throw new Exception("Початковий баланс не може бути меншим за " . self::MIN_BALANCE);
            }
            $this->currency = $currency;
            $this->balance = $initialBalance;
        }

        public function deposit($amount) {
            if ($amount <= 0) {
                throw new Exception("Сума поповнення повинна бути додатною");
            }
            $this->balance += $amount;
        }

        public function withdraw($amount) {
            if ($amount <= 0) {
                throw new Exception("Сума зняття повинна бути додатною");
            }
            if ($this->balance - $amount < self::MIN_BALANCE) {
                throw new Exception("Недостатньо коштів для зняття");
            }
            $this->balance -= $amount;
        }

        public function getBalance() {
            return $this->balance . ' ' . $this->currency;
        }
    }
?>
