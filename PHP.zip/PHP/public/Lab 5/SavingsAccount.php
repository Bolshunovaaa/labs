<?php
    require_once 'BankAccount.php';

    class SavingsAccount extends BankAccount {
        public static $percentage = 0.1;

        public function applyPercentage() {
            $interest = $this->balance * self::$percentage;
            $this->balance += $interest;
        }
    }
?>
