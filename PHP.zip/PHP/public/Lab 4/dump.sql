DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "username" character varying(50) NOT NULL,
    "email" character varying(100) NOT NULL,
    "password" character varying(255) NOT NULL,
    CONSTRAINT "users_email_key" UNIQUE ("email"),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "users_username_key" UNIQUE ("username")
) WITH (oids = false);

INSERT INTO "users" ("id", "username", "email", "password") VALUES
(1,	'user_1',	'user_1@gmail.com',	'e10adc3949ba59abbe56e057f20f883e'),
(2,	'user_2',	'user_2@gmail.com',	'e10adc3949ba59abbe56e057f20f883e');
