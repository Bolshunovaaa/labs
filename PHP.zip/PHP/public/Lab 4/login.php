<?php
    session_start();

    $dsn = "pgsql:host=postgres;port=5432;dbname=users_db";
    $user = "laravel-getting-started-user";
    $pass = "laravel-getting-started-password";

    try {
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && $user['password'] === $password) {
                $_SESSION['username'] = $username;
                header("Location: welcome.php");
                exit();
            } else {
                echo "Невірне ім'я користувача або пароль!";
            }
        }
    } catch (PDOException $e) {
        echo "Сталася помилка під час авторизації.";
    }
?>
