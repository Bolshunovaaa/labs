<?php
    $dsn = "pgsql:host=postgres;port=5432;dbname=users_db";
    $user = "laravel-getting-started-user";
    $pass = "laravel-getting-started-password";

    try {
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = md5($_POST['password']);

            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) 
                                VALUES (:username, :email, :password)");
            $stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password' => $password
            ]);

            echo "Користувача успішно зареєстровано!";
        }
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'users_username_key')) {
            echo "Ім’я користувача вже існує.";
        } elseif (str_contains($e->getMessage(), 'users_email_key')) {
            echo "Email вже використовується.";
        } else {
            echo "Сталася помилка під час реєстрації.";
        }
    }
?>
